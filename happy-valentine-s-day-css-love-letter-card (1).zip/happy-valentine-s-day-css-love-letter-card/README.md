# Happy Valentine's Day / CSS Love letter/ card

A Pen created on CodePen.

Original URL: [https://codepen.io/lenasta92579651/pen/mdrogRR](https://codepen.io/lenasta92579651/pen/mdrogRR).

